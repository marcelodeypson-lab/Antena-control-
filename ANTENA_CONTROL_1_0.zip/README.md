# ANTENA CONTROL — versão 1.0

Projeto Android nativo inicial para Android Studio, direcionado ao Moto G60s.

## O que esta versão faz
- Solicita a permissão `READ_PHONE_STATE`.
- Recebe atualizações de intensidade de sinal do Android e tenta apresentar o valor em dBm.
- Identifica a tecnologia de rede de dados quando o sistema disponibiliza essa informação.
- Abre as configurações de rede do Android.

## O que ainda não faz
- Não altera a potência de transmissão RF.
- Não força potência mínima/máxima.
- Não muda bandas LTE nem parâmetros proprietários do modem.

Esses controles não são disponibilizados por uma API Android comum. Root, por si só, não garante acesso; depende do firmware, modem e permissões específicas.

## Como abrir
1. Instale o Android Studio em um computador.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `ANTENA_CONTROL`.
4. Aguarde a sincronização do Gradle.
5. Conecte o Moto G60s por USB, habilite Depuração USB nas Opções do desenvolvedor e execute o projeto.
6. Aceite a permissão de telefone quando solicitada.

O projeto usa Android Gradle Plugin 8.6.1 e compileSdk 35. O Android Studio pode solicitar instalação desse SDK e de componentes do Gradle.

## Sobre as leituras
A disponibilidade e a precisão do dBm dependem do modem, da operadora e da versão do Android. A qualidade exibida é uma classificação aproximada, não uma medição oficial de qualidade de chamada ou velocidade.
